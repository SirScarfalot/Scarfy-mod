This is Sir Scarfalot's personal mod: Okay, maybe I went overdramatic here before. I do apologize for that.

Anyway, ammonia comes from urine historically. I've made a recipe for ammonia that uses feces as a stand-in, but I suspect feces could work on their own as well even if it isn't historically accurate.